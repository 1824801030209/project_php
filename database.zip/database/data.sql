-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th12 07, 2020 lúc 09:24 AM
-- Phiên bản máy phục vụ: 10.4.14-MariaDB
-- Phiên bản PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `data`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `cart`
--

CREATE TABLE `cart` (
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `users_id` int(10) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `cart`
--

INSERT INTO `cart` (`product_id`, `quantity`, `users_id`, `id`, `status`) VALUES
(1, 1, 8, 19, 1),
(2, 2, 8, 21, 1),
(2, 1, 8, 22, 1),
(2, 1, 8, 23, 1),
(3, 3, 8, 24, 1),
(2, 1, 11, 25, 0),
(7, 6, 8, 26, 1),
(1, 1, 8, 37, 1),
(6, 3, 8, 38, 1),
(7, 3, 8, 39, 1),
(1, 1, 8, 40, 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` float NOT NULL,
  `price_sale` float NOT NULL,
  `image_url` varchar(255) NOT NULL,
  `heathy_description` varchar(255) NOT NULL,
  `description` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `product`
--

INSERT INTO `product` (`id`, `name`, `price`, `price_sale`, `image_url`, `heathy_description`, `description`) VALUES
(1, 'Dâu tây', 10000, 0, './images/Traicay/dautay.jpg', 'lợi ich', 'ksadsadsadsadsadsad'),
(2, 'xoài', 20000, 10000, './images/Traicay/xoai.jpg', 'lợi ích', 'ksadsadsadsadsadsad'),
(3, 'chôm chôm', 20000, 0, './images/Traicay/chomchom.jpg', 'sadsad', 'dasd'),
(5, 'dưa hấu', 50000, 0, './images/Traicay/dua.jpg', 'ddasda', 'sadsadas'),
(6, 'măng cụt', 50000, 24000, './images/Traicay/mangcut.jpg', 'asdsadsad', 'sadasdasd'),
(7, 'Sầu Riêng', 100000, 50000, './images/Traicay/saurieng.jpg', 'asdsadsad', 'sadasdasd');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(50) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `phone`, `email`) VALUES
(1, 'superAdmin', 'e10adc3949ba59abbe56e057f20f883e', '0987654433', 'admin@admin.com'),
(2, 'Admin', 'e10adc3949ba59abbe56e057f20f883e', '0987654433', 'admin1@admin.com'),
(4, 'minh', '25f9e794323b453885f5181f1b624d0b', '213456789', 'minh@gmail.com'),
(5, 'minh123', '202cb962ac59075b964b07152d234b70', '', 'minh@asdadsa.com'),
(6, 'minh123', '202cb962ac59075b964b07152d234b70', '0970979871', 'minh@asdadsa.com'),
(7, 'minh123', '202cb962ac59075b964b07152d234b70', '0970979871', 'minh@asdadsa.com'),
(8, '0969289752xx', '202cb962ac59075b964b07152d234b70', '(+84) 969289752', 'nhutphan25082000@gmail.com'),
(9, '0969289752xx', '202cb962ac59075b964b07152d234b70', '(+84) 969289752', 'nhutphan25082000@gmail.com'),
(10, 'onionsmit', '202cb962ac59075b964b07152d234b70', '(+84) 969289752', 'nhutphan25082000@gmail.com'),
(11, 'minh', '202cb962ac59075b964b07152d234b70', '1234567890', '123123@gmail.com');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `PRODUCT_CART` (`product_id`),
  ADD KEY `USERS_CART` (`users_id`);

--
-- Chỉ mục cho bảng `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT cho bảng `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT cho bảng `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `PRODUCT_CART` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `USERS_CART` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
